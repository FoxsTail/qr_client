CREATE VIEW equipment_shortcut_view AS
  SELECT
    `e`.`id`            AS `id`,
    `t`.`type`          AS `type`,
    `v`.`vendor`        AS `vendor`,
    `m`.`model`         AS `model`,
    `m`.`series`        AS `series`,
    `e`.`inventory_num` AS `inventory_num`,
    `e`.`room`          AS `room`
  FROM (((`qr_project`.`equipment` `e`
    JOIN `qr_project`.`type` `t` ON ((`e`.`id_type` = `t`.`id`))) JOIN `qr_project`.`model` `m`
      ON ((`e`.`id_model` = `m`.`id`))) JOIN `qr_project`.`vendor` `v` ON ((`m`.`id_vendor` = `v`.`id`)));
